# Waves Bot - Quick Start Guide

Waves Bot lets you define Discord bot commands using readable sentence-style instructions. It's powerful, easy to use, and built for customization.

---

## ✅ Getting Started

### 1. Install Node.js
Download and install Node.js from https://nodejs.org

### 2. Install Dependencies
Open your terminal in this folder and run:
```bash
npm install
```

### 3. Configure the Bot
Open `config.js` and update your bot token:

```js
module.exports = {
    token: 'YOUR_BOT_TOKEN_HERE',
    mode: 'modular',
    commandSource: 'commands'
};
```

### 4. Add Your Commands
Create `.waves` files inside the `commands/` folder.

#### Example command:
```waves
IF user says "hello" SEND "Hi there! I am Waves."
```

### 5. Run the Bot
```bash
node index.js
```

---

## 💡 Example Commands

| Action        | Example Syntax                                                                 |
|---------------|----------------------------------------------------------------------------------|
| Send Message  | `IF user says "hi" SEND "Hello!"`                                               |
| Kick Member   | `IF user says "kick" KICK <@USER_ID> reason "Breaking rules"`                   |
| Ban Member    | `IF user says "ban" BAN <@USER_ID> reason "Toxicity"`                           |
| Mute User     | `IF user says "mute" MUTE <@USER_ID> for 5 minutes reason "Spamming"`          |
| Embed Message | `IF user says "info" SEND EMBED { "title": "Info", "description": "Hello!" }` |
| Combo Message | `SEND 1by1 "Step 1" THEN "Step 2" THEN "Step 3"`                                |
| Combined Msg  | `SEND together "Line 1" AND "Line 2" AND "Line 3"`                             |

---

## 🛡 Permissions Checklist

Ensure your bot has these permissions in your server:
- Read Messages
- Send Messages
- Kick Members
- Ban Members
- Moderate Members (for mutes)

Also enable these in your bot settings on Discord Developer Portal:
- Message Content Intent
- Server Members Intent

---

## ℹ Notes

- All command files must use `.waves` extension.
- JSON inside `SEND EMBED` must be valid.
- Use Developer Mode in Discord to copy IDs (user, channel, etc).

Enjoy building with Waves Bot!
